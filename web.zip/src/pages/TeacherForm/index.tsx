import React, {ReactElement} from 'react';

import { Link } from 'react-router-dom';
import './styles.css';


function TeacherForm(): ReactElement {
	
	return (
	<h1>aa</h1>
	
	);
}

export default TeacherForm;